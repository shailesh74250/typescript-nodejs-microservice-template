import { Router } from 'express';
const v1 = Router();

// v1.use('/your-endpoint', your_service_router);

export default v1;
